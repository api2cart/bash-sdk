# CartScriptAdd_200_response_result

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scriptUnderscoreid** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


