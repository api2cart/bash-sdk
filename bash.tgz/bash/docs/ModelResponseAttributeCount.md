# Model_Response_Attribute_Count

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnUnderscorecode** | **integer** |  | [optional] [default to null]
**returnUnderscoremessage** | **string** |  | [optional] [default to null]
**result** | [**ResponseAttributeCountResult**](ResponseAttributeCountResult.md) |  | [optional] [default to null]
**additionalUnderscorefields** | **map** |  | [optional] [default to null]
**customUnderscorefields** | **map** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


