# OrderReturnUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnUnderscoreid** | **string** |  | [default to null]
**orderUnderscoreid** | **string** |  | [optional] [default to null]
**storeUnderscoreid** | **string** |  | [optional] [default to null]
**itemUnderscorerestock** | **boolean** |  | [optional] [default to false]
**returnUnderscorestatusUnderscoreid** | **string** |  | [optional] [default to null]
**returnUnderscorereasonUnderscoreid** | **string** |  | [optional] [default to null]
**returnUnderscoreactionUnderscoreid** | **string** |  | [optional] [default to null]
**staffUnderscorenote** | **string** |  | [optional] [default to null]
**comment** | **string** |  | [optional] [default to null]
**message** | **string** |  | [optional] [default to null]
**sendUnderscorenotifications** | **boolean** |  | [optional] [default to false]
**rejectUnderscorereason** | **string** |  | [optional] [default to null]
**returnUnderscoreaction** | **string** |  | [optional] [default to null]
**returnUnderscorereason** | **string** |  | [optional] [default to null]
**isUnderscoreonline** | **boolean** |  | [optional] [default to false]
**feeUnderscoreprice** | **integer** |  | [optional] [default to null]
**shippingUnderscoreprice** | **integer** |  | [optional] [default to 0]
**idempotencyUnderscorekey** | **string** |  | [optional] [default to null]
**orderUnderscoreproducts** | [**array[OrderReturnUpdateOrderProductsInner]**](OrderReturnUpdateOrderProductsInner.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


