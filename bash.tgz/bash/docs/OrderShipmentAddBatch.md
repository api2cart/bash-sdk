# OrderShipmentAddBatch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**array[OrderShipmentAddBatchPayloadInner]**](OrderShipmentAddBatchPayloadInner.md) |  | [default to null]
**idempotencyUnderscorekey** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


