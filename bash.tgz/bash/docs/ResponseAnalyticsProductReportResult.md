# Response_Analytics_ProductReport_Result

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**period** | [**AnalyticsPeriod**](AnalyticsPeriod.md) |  | [optional] [default to null]
**items** | [**array[AnalyticsProduct]**](AnalyticsProduct.md) |  | [optional] [default to null]
**additionalUnderscorefields** | **map** |  | [optional] [default to null]
**customUnderscorefields** | **map** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


