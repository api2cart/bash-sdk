# Response_Return_Action_List_Result

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**returnUnderscoreactions** | [**array[Status]**](Status.md) |  | [optional] [default to null]
**additionalUnderscorefields** | **map** |  | [optional] [default to null]
**customUnderscorefields** | **map** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


