# StoreAttribute_Group

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] [default to null]
**name** | **string** |  | [optional] [default to null]
**position** | **integer** |  | [optional] [default to null]
**attributeUnderscoresetUnderscoreid** | **string** |  | [optional] [default to null]
**assignedUnderscoreattributeUnderscoreids** | **array[string]** |  | [optional] [default to null]
**additionalUnderscorefields** | **map** |  | [optional] [default to null]
**customUnderscorefields** | **map** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


